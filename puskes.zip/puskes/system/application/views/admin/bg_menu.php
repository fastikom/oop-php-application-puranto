	<div class="container-fluid-full">
		<div class="row-fluid">

			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li><a href="<?php echo base_url()?>index.php/admin">
                        <i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
						<li><a href="<?php echo base_url()?>index.php/admin/katobat">
                        <i class="icon-list"></i><span class="hidden-tablet"> Kategori Obat</span></a></li>
                        <li><a href="<?php echo base_url()?>index.php/admin/cekobat">
                        <i class="icon-eye-open"></i><span class="hidden-tablet"> Stok Obat</span></a></li>
						<li><a href="<?php echo base_url()?>index.php/admin/transaksi">
                        <i class="icon-eye-open"></i><span class="hidden-tablet"> Transaksi Obat</span></a></li>
                        <li><a href="<?php echo base_url()?>index.php/admin/transaksiobat">
                        <i class="icon-list"></i><span class="hidden-tablet"> Data Transaksi Obat</span></a></li>
						<li><a href="<?php echo base_url()?>index.php/admin/akses">
                        <i class="icon-group"></i><span class="hidden-tablet"> Data User</span></a></li>
                        <li><a href="<?php echo base_url()?>index.php/admin/laporan">
                        <i class="icon-file-alt"></i><span class="hidden-tablet"> Laporan</span></a></li>
                        <li><a href="<?php echo base_url()?>index.php/admin/laporantransaksi">
                        <i class="icon-file-alt"></i><span class="hidden-tablet"> Laporan Transaksi</span></a></li>
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->